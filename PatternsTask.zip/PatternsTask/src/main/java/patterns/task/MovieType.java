package patterns.task;

public interface MovieType {
    double getAmount(int daysRented);
}
